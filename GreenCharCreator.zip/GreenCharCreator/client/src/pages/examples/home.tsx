import Home from "../home";

export default function HomeExample() {
  return <Home />;
}
